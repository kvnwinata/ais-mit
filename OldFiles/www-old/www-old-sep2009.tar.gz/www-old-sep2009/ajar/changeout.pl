opendir(DIR,"."); 
while ($file=readdir DIR){
    $file=~ s/\.out//;
#    print "mv $file.out $file\n" if ($file!~/^\./);
    system("mv $file.out $file\n") if ($file!~/^\./);
}
