<?php

if (!isset($language)) {
   $language="english";		// set default language
}

// First, check if submit button is pressed if not, display the form.

if (!isset($Submit)) {

   if ($language == 'english') {
      include("survey_e.html");
   } else if ($language == 'indonesian') {
      include("survey_i.html");
   }

} else {			// if this is processed, then the submit button must have been pressed
				// codes for submitting the survey to mysql database server
   $db = mysql_connect("localhost", "root", "1c3r#2000");
   mysql_select_db("survey", $db);

   $sql = "INSERT INTO survey_tbl (id, lokasi, perguruan, q1, q2email, q2chat, q2browse, q2situs, q2buy, q2other, q2otherval, q3, q4search, q4pribadi, q4perusahaan, q4univ, q4other, q4otherval, q5a, q5b, q5c, q5d, q6a, q6b, q7, q8, q9, q10, q11, q12, q13, q14, comment, email, origin) values ('', ";
   $sql .= "'$lokasi', ";
   $sql .= "'$perguruan', ";
   $sql .= "'$q1', ";
   $sql .= "'$q2email', ";
   $sql .= "'$q2chat', ";
   $sql .= "'$q2browse', ";
   $sql .= "'$q2situs', ";
   $sql .= "'$q2buy', ";
   $sql .= "'$q2other', ";
   $sql .= "'$q2otherval', ";
   $sql .= "'$q3', ";
   $sql .= "'$q4search', ";
   $sql .= "'$q4pribadi', ";
   $sql .= "'$q4perusahaan', ";
   $sql .= "'$q4univ', ";
   $sql .= "'$q4other', ";
   $sql .= "'$q4otherval', ";
   $sql .= "'$q5a', ";
   $sql .= "'$q5b', ";
   $sql .= "'$q5c', ";
   $sql .= "'$q5d', ";
   $sql .= "'$q6a', ";
   $sql .= "'$q6b', ";
   $sql .= "'$q7a', ";
   $sql .= "'$q8a', ";
   $sql .= "'$q9', ";
   $sql .= "'$q10', ";
   $sql .= "'$q11', ";
   $sql .= "'$q12', ";
   $sql .= "'$q13', ";
   $sql .= "'$q14', ";
   $sql .= "'$comment', ";
   $sql .= "'$email', ";
   $sql .= "'$REMOTE_ADDR') ";

   mysql_query($sql);

   include("thanks.html");
}
