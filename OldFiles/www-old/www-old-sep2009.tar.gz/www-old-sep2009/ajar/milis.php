<?php

   $db = mysql_connect("localhost", "root", "1c3r#2000");
   mysql_select_db("survey", $db);

   $sql = "INSERT INTO $table (name, email, affiliation, expert, origin) values (";
   $sql .= "'$name', ";
   $sql .= "'$email', ";
   $sql .= "'$affiliation', ";
   $sql .= "'$expert', ";
   $sql .= "'$REMOTE_ADDR') ";

   mysql_query($sql);

   include("$post_html");
?>
