#! /usr/bin/perl/ -w

opendir(DIR,'.');
while($file=readdir(DIR)){
    next unless !($file=~/out/);
    open(OUT,">$file.out");
    open(IN,"<$file");
    while(<IN>){
	if(/images/){
	    s/\/images/\.\/images/g;
	    print $_;
	}
	print OUT $_;
    }
    close(IN);
}
